
# Metodologia

O método ágil adotado neste projeto é o SCRUM, um framework que proporciona maior organização, eficiência e adaptabilidade ao desenvolvimento de software. Sua abordagem é baseada na entrega incremental do produto, por meio de ciclos curtos e contínuos denominados sprints, garantindo uma evolução constante e alinhada às necessidades do projeto.

O SCRUM estrutura papéis bem definidos, promovendo um fluxo de trabalho disciplinado e colaborativo. Essa estruturação permite a divisão eficiente das tarefas, fortalecendo a equipe para enfrentar desafios e aprimorando a comunicação entre os membros.

A metodologia incentiva a troca de conhecimento e o debate construtivo de ideias, resultando em soluções mais inovadoras e adaptáveis. Dessa forma, esse método ágil não apenas otimiza o processo de desenvolvimento, mas também melhora a qualidade do produto final e a satisfação dos envolvidos.

## Gerenciamento de Projeto
### Divisão de Papéis

A equipe utiliza o Scrum como base para definição do processo de desenvolvimento.
- Scrum Master: João Pedro Pereira
- Product Owner: Erivaldo Gelson da Rocha João
- Equipe de Desenvolvimento: João Pedro Pereira , Erivaldo da Rocha João , Matheus Veríssimo dos Santos , Felipe Bernardi
- Equipe de Design: João Pedro Pereira , Erivaldo Gelson da Rocha João.

### Processo

Para a implementação do SCRUM, adotamos uma série de práticas ágeis que garantem a organização, eficiência e transparência ao longo do desenvolvimento do projeto. Essas práticas não só promovem a colaboração da equipe, mas também asseguram que as entregas sejam feitas de forma incremental e alinhada com os objetivos do cliente.

Cerimônias do SCRUM:

Sprint Planning: Ao início de cada Sprint, a equipe realiza uma reunião de planejamento, onde os itens do Backlog do Produto são selecionados e detalhados. A principal tarefa dessa cerimônia é definir as metas para a Sprint, atribuindo tarefas específicas aos membros da equipe e garantindo que todos compreendam claramente as atividades a serem realizadas.

Daily Standup: São reuniões diárias rápidas, com duração de aproximadamente 15 minutos, nas quais cada membro da equipe compartilha seu progresso, os desafios encontrados e as tarefas que serão executadas até o próximo encontro. Essas reuniões são essenciais para manter todos os membros alinhados e identificar rapidamente quaisquer impedimentos que possam surgir.

Sprint Review: Ao final de cada Sprint, a equipe realiza uma reunião de revisão, onde o trabalho realizado é apresentado ao Product Owner e outros stakeholders. Essa cerimônia tem como objetivo obter feedback sobre as entregas da Sprint, verificar se as expectativas foram atendidas e ajustar o trabalho para a próxima iteração, se necessário.

Sprint Retrospective: Após a Sprint Review, a equipe realiza uma reunião de retrospectiva. Neste encontro, a equipe reflete sobre o processo de trabalho da Sprint anterior, identificando pontos positivos, oportunidades de melhoria e ações concretas para otimizar a produtividade e a qualidade no próximo ciclo.

Gestão do Projeto no GitHub:

Para facilitar a organização e o acompanhamento das atividades, a equipe utiliza o GitHub Project. Através do Quadro Kanban, as tarefas são distribuídas de forma visual e clara, garantindo que todos os membros da equipe saibam o status de cada atividade. O quadro está organizado da seguinte forma:
<ul>
<li>Product Backlog:Esta lista contém todas as tarefas, funcionalidades e melhorias a serem implementadas ao longo do projeto. Representa o Backlog do Produto, onde todas as atividades são inicialmente registradas e priorizadas conforme as necessidades do cliente.</li>
<li>To Do: Aqui estão as tarefas que foram selecionadas para a Sprint atual, também conhecidas como Sprint Backlog. Essas atividades estão prontas para serem iniciadas e são a base para o trabalho da equipe durante o ciclo da Sprint.</li>
<li>In Progress: Esta lista contém as tarefas que já foram iniciadas. À medida que os membros da equipe começam a trabalhar nas atividades, elas são movidas para essa coluna, garantindo visibilidade do progresso do trabalho em andamento.</li>
<li>Done: As tarefas que foram concluídas, testadas e validadas entram nesta lista. Elas estão prontas para serem entregues ao cliente ou stakeholders e são consideradas entregas finalizadas. A movimentação para essa lista indica que as atividades passaram pelos controles de qualidade e estão de acordo com os requisitos definidos.</li>
</ul>
<figure> 
  <img src="https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t2-mindtrack/blob/main/documentos/img/Captura%20de%20tela%202025-04-02%20210529.png?raw=true"
</figure> 
### Etiquetas
<p>As tarefas são, ainda, etiquetadas em função da natureza da atividade e seguem o seguinte esquema de cores/categorias:</p>

<ul>
 <li>BackLog</li>
 <li>Amalise Tecnica</li>
 <li>Pronto para desenvolvimento</li>
 <li>Em desenvolvimento</li>
 <li>Está feito</li>
 <li>Testes</li>
</ul>


  
### Ferramentas

| AMBIENTE                            | PLATAFORMA                         | LINK DE ACESSO                         |
|-------------------------------------|------------------------------------|----------------------------------------|
| Repositório de código fonte         | GitHub                             | https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t2-mindtrack/tree/main/codigo-fonte                            |
| Documentos do projeto               | GitHub                             | https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t2-mindtrack/blob/main/documentos/01-Documentação%20de%20Contexto.md                           |
| Projeto de Interface                | Figma                              | https://www.figma.com/design/ykP1LkJUVMz0wjcnAfuNJD/Projeto?node-id=0-1&p=f&t=VFrmwPQ4j8liTfUB-0|
| Gerenciamento do Projeto            | GitHub Projects                    | http://....                            |
| Hospedagem                          | GitHub Pages                       | http://....                            |


### Estratégia de Organização de Codificação 

Todos os artefatos relacionados a implementação e visualização dos conteúdos do projeto do site deverão ser inseridos na pasta [codigo-fonte](http://https://github.com/ICEI-PUC-Minas-PMV-ADS/WebApplicationProject-Template-v2/tree/main/codigo-fonte). Consulte também a nossa sugestão referente a estratégia de organização de codificação a ser adotada pela equipe de desenvolvimento do projeto.
