# Especificação do Projeto

## Perfis de Usuários


<table>
<tbody>
<tr align=center>
<th colspan="2">Perfil 01: Aluno </th>
</tr>
<tr>
<td width="150px"><b>Descrição:</b></td>
<td width="600px">Aluno do ensino médio, seja educação pública ou privada</td>
</tr>
<tr>
<td><b>Necessidades</b></td>
<td>1.Lembrança de prazos e compromissos – Precisa de um sistema para não esquecer datas de provas e entregas de trabalhos.

2.Divisão clara das matérias – Necessita de uma maneira simples de separar o conteúdo por matérias e tópicos, facilitando o estudo.

3.Planejamento diário de estudo – Precisa de uma forma de organizar o que estudar a cada dia, com objetivos alcançáveis.

4.Acompanhamento de progresso – Necessita de um modo de verificar seu desempenho e ver o que já estudou ou precisa revisar.

5.Redução de distrações – Precisa de ferramentas ou métodos que ajudem a manter o foco e minimizar as distrações enquanto estuda.
</td>
</tr>
</tbody>
</table>

<table>
<tbody>
<tr align=center>
<th colspan="2">Perfil 02: Estudante </th>
</tr>
<tr>
<td width="150px"><b>Descrição:</b></td>
<td width="600px">Estudantes de Cursos Técnicos</td>
</tr>
<tr>
<td><b>Necessidades</b></td>
<td>	1..Gestão de tempo eficiente – Precisa de uma ferramenta para equilibrar os estudos com outras responsabilidades, como estágio ou trabalho, e otimizar o tempo disponível para aprender.

2.Planejamento detalhado de disciplinas e projetos – Necessita de uma forma de planejar de maneira clara e estruturada suas aulas práticas e teóricas, considerando prazos de entrega de projetos e provas.

3.Acompanhamento de desempenho nas atividades práticas – Precisa de um sistema para acompanhar seu progresso nas atividades práticas e teóricas, ajudando a identificar pontos fortes e áreas a melhorar.

4.Organização de materiais de estudo – Precisa de uma ferramenta para organizar seus materiais de estudo, como apostilas, anotações e recursos digitais, facilitando o acesso a conteúdo importante.

5.Lembretes e alertas para prazos de tarefas – Necessita de lembretes para não perder prazos importantes de provas, entrega de trabalhos e avaliações práticas, ajudando a manter a organização.

</td>
</tr>
</tbody>
</table>



## Histórias de Usuários

[Apresente aqui as histórias de usuários que são relevantes para o projeto da solução.]

> **Link Útil**:
> - [Como escrever boas histórias de usuário](https://medium.com/vertice/como-escrever-boas-users-stories-hist%C3%B3rias-de-usu%C3%A1rios-b29c75043fac)

[Utilize o modelo de tabela abaixo para apresentar as histórias de usuários.]

|EU COMO... `QUEM`   | QUERO/PRECISO ... `O QUE` |PARA ... `PORQUE`                 |
|--------------------|---------------------------|----------------------------------|
|Aluno do Ensino Médio |Preciso de uma ferramenta que me ajude a organizar os horários de estudo e me avise sobre prazos de provas e trabalhos.  |Porque sempre deixo as coisas para a última hora e acabo esquecendo de datas importantes.                             |
|Aluna Universitária                | Preciso de um sistema que me ajude a balancear meus estudos e estágio, com lembretes e um cronograma visual.                     |Porque, com tantas tarefas e responsabilidades, acabo perdendo o controle do meu tempo e procrastinando.                              |
|Aluna de Curso Técnico |Preciso de uma ferramenta que organize meus estudos teóricos e práticos, e me avise sobre prazos de entrega de projetos |Porque as aulas práticas e os prazos de projetos muitas vezes se confundem com as tarefas teóricas e me sinto desorganizada.

## Requisitos do Projeto

[Com base nas Histórias de Usuários, enumere os requisitos da solução. Lembre-se que cada requisito deve corresponder a uma, e somente uma, característica alvo da solução. Além disso, certifique-se de que todos os aspectos capturados nas Histórias de Usuário foram cobertos.]

### Requisitos Funcionais

[Utilize o modelo de tabela abaixo para apresentar os requisitos funcionais]

|ID    | Descrição                | Prioridade |
|-------|---------------------------------|----|
| RF-01 |  A aplicação deve permitir ao usuário cadastrar uma conta.                     | ALTA  | 
| RF- 02  |  A aplicação deve permitir ao usuário fazer o login da sua conta                   | ALTA  |
|  RF- 03  | O sistema deve permitir ao usuário criar um cronograma de estudos, com prazos para provas e entregas de trabalhos.                   | ALTA   |
|  RF- 04 |  O sistema deve permitir ao usuário cadastrar e visualizar seus horários de estudo.                  | ALTA   |
|  RF- 05  | O sistema deve enviar lembretes de prazos de provas, trabalhos e projetos.                 | ALTA   |
|  RF- 06  | O sistema deve permitir o cadastro de diferentes tipos de tarefas (teóricas, práticas, etc.)                  | MÉDIA   |
|  RF- 07  | O sistema deve exibir estatísticas de progresso dos estudos com gráficos e indicadores.                  | ALTA  |
|  RF- 08  | O sistema deve permitir configurar metas diárias de estudo personalizadas                  | MÉDIA |
|  RF- 09  | O sistema deve permitir ao usuário conciliar diferentes atividades (ex: estudo e estágio).                  | ALTA   |
|  RF- 10 |  O sistema deve possibilitar edição e exclusão de tarefas e eventos cadastrados.                    | ALTA   |


**Prioridade: Alta / Média / Baixa. 

### Requisitos não Funcionais

[Utilize o modelo de tabela abaixo para apresentar os requisitos não-funcionais]

|ID      | Descrição               |Prioridade |
|--------|-------------------------|----|
| RNF-01 | O sistema deve ser responsivo, adaptando-se a diferentes tamanhos de tela (desktop, tablet e smartphone).                   | ALTA  | 
| RNF- 02   | O sistema deve ter uma interface intuitiva e de fácil navegação para o usuário.                |ALTA  |
| RNF- 03  | O sistema deve garantir o armazenamento seguro dos dados do usuário.                 | ALTA   |
|RNF- 04  |O sistema deve apresentar bom desempenho, com tempo de carregamento inferior a 3 segundos por página.                 |MÉDIA   |
| RNF- 05   |  O sistema deve estar disponível 24 horas por dia, 7 dias por semana, com alta disponibilidade.                  | MÉDIA  |
|RNF- 06|O sistema deve permitir escalabilidade para suportar aumento no número de usuários|BAIXA|
|RNF- 07|O sistema deve ser compatível com os principais navegadores (Chrome, Firefox, Edge, Safari).|ALTA|

**Prioridade: Alta / Média / Baixa. 

