# Introdução

Organizar os estudos é um desafio comum para muitos estudantes, como mostra uma reportagem do portal Terra, que revelou que 67% dos alunos têm dificuldades para manter uma rotina estruturada, especialmente em momentos de maior pressão, como na pandemia. Isso evidencia a importância de ferramentas que realmente ajudem a planejar o tempo e as tarefas acadêmicas de forma mais eficiente.
Com a grande quantidade de conteúdo para aprender e prazos sempre apertados, é fácil acabar procrastinando, ficando estressado ou tendo um rendimento abaixo do esperado. Muitos tentam usar agendas físicas, aplicativos de anotações e lembretes, mas, por não estarem integrados, essas soluções nem sempre facilitam o acompanhamento do progresso.
Pensando nisso, uma plataforma online para organizar os estudos pode ser a chave para resolver esse problema. A ideia é reunir cronogramas, prazos e o progresso acadêmico em um só lugar, de maneira intuitiva e personalizável. Dessa forma, os estudantes poderiam se planejar melhor, reduzir o estresse e aumentar a produtividade, tornando o aprendizado mais fluido e acessível.
## Problema
A desorganização nos estudos é um desafio para muitos estudantes, levando à procrastinação, estresse e dificuldades no aprendizado. O uso disperso de ferramentas como agendas e aplicativos dificulta o acompanhamento do progresso, resultando em sobrecarga antes das provas e negligência de conteúdos importantes. Além disso, a falta de um planejamento estruturado impacta a motivação e a constância nos estudos. Diante disso, há a necessidade de uma solução integrada que auxilie no planejamento, monitoramento e acompanhamento do desempenho acadêmico, tornando os estudos mais eficientes e organizados.


Este link pode ajudar a equipe a entender mais sobre definição do problema: [Objetivos, Problema de pesquisa e Justificativa.](https://medium.com/@versioparole/objetivos-problema-de-pesquisa-e-justificativa-c98c8233b9c3)


## Objetivos

O objetivo principal deste projeto é desenvolver uma aplicação web para organizar os estudos, ajudando os estudantes a gerenciar tarefas, prazos e progresso acadêmico de forma eficiente. A solução visa centralizar informações acadêmicas, facilitar o planejamento com cronogramas personalizados, e fornecer notificações e lembretes para o cumprimento de prazos. Além disso, a plataforma permitirá que os usuários acompanhem seu progresso e mantenham uma rotina de estudos consistente, visando melhorar a produtividade e reduzir o estresse.

#Objetivos Específicos:

Centralizar informações acadêmicas em um único espaço para o registro e acompanhamento de disciplinas, tarefas e prazos.
Facilitar o planejamento de estudos com ferramentas para criar cronogramas personalizados e definir metas de aprendizado.
Acompanhar o progresso acadêmico por meio de recursos que permitem visualizar a evolução nos estudos e ajustar o planejamento.
Fornecer notificações e lembretes para garantir o cumprimento de prazos e compromissos acadêmicos.
Promover a constância nos estudos com funcionalidades que incentivem a regularidade e a produtividade.
Disponibilizar uma interface intuitiva e acessível, garantindo facilidade de uso para estudantes de diferentes perfis.
Permitir personalização da experiência para atender às necessidades individuais dos usuários.

## Justificativa

A dificuldade na organização e planejamento dos estudos impacta diretamente o desempenho acadêmico, tornando-se um desafio para muitos estudantes. Um levantamento do Instituto Unibanco aponta que 44% dos alunos consideram a organização dos estudos uma de suas maiores dificuldades. Além disso, a pesquisa "Juventudes na Escola" revela que mais de 60% dos jovens enfrentam problemas para conciliar estudo e outras responsabilidades, o que pode levar à desmotivação e ansiedade.
Com base nesses dados e em entrevistas realizadas com estudantes universitários, percebe-se que a falta de gestão do tempo compromete a produtividade e a aprendizagem. As entrevistas revelaram que a maioria dos estudantes relatou dificuldade em estabelecer prioridades, manter regularidade nos estudos e lidar com a sobrecarga de tarefas, reforçando os dados apresentados pelas fontes institucionais.
Diante desse cenário, este estudo propõe o desenvolvimento de uma aplicação web que auxilie na organização dos estudos por meio de cronogramas personalizados, lembretes e acompanhamento de metas. O objetivo é oferecer um suporte prático e acessível para melhorar a autonomia dos estudantes, promovendo uma rotina acadêmica mais eficiente e equilibrada.


## Público-Alvo

Público-alvo
O problema de desorganização nos estudos afeta diferentes perfis de usuários, cada um com suas características, necessidades e experiência com a tecnologia. Para entender melhor essas necessidades, serão realizadas entrevistas e questionários com estudantes de diferentes níveis de ensino, a fim de refinar as funcionalidades da aplicação e atender aos desafios enfrentados por cada grupo. Abaixo estão os principais perfis de usuários identificados:
#1. Estudantes do Ensino Médio
Características: Jovens de 14 a 18 anos, muitas vezes no início da jornada escolar, com pouca experiência em ferramentas de produtividade.
Necessidades: Necessitam organizar suas matérias escolares, controlar prazos de provas e trabalhos e monitorar seu progresso acadêmico.
Conhecimento Tecnológico: Familiaridade com aplicativos móveis e plataformas educacionais básicas, mas pouca experiência com ferramentas avançadas de produtividade.
#2. Universitários e Estudantes de Cursos Técnicos Características:
 Jovens e adultos que conciliam os estudos com outras responsabilidades, como trabalho e estágio.
Necessidades: Demandam uma gestão eficiente de cronogramas, lembretes para prazos acadêmicos, categorização de disciplinas e recursos para planejamento detalhado dos estudos.
Conhecimento Tecnológico: Maior familiaridade com tecnologia, uso frequente de plataformas acadêmicas e ferramentas de produtividade, como Google Calendar e Trello.
#3. Concurseiros e Autodidatas 
Características:
Pessoas que estudam por conta própria para concursos, certificações ou aprimoramento profissional.
Necessidades: Precisam de planejamento detalhado, acompanhamento de progresso e estatísticas de estudo, além de personalização do cronograma de aprendizado para otimizar a preparação.
Conhecimento Tecnológico: Dependendo do perfil, podem ter grande experiência com aplicativos de organização e métodos digitais de estudo.
