# Template padrão da Aplicação

O layout padrão do site foi construído com as linguagens de marcação HTML e CSS, e a linguagem de programação JavaScript foi utilizada para a construção do menu responsivo.

As páginas terão como elementos padrões o menu de navegação, o header e o footer, além dos elementos de identidade visual citados abaixo:

 --header-height: 3rem;
    --nav-width: 68px;
    --first-color: #27594B;
    --first-color-light: #AFA5D9;
    --white-color: #F7F6FB;
    --body-font: 'Nunito', sans-serif;
    --normal-font-size: 1rem;
    --z-fixed: 100;

O código utilizado para a construção dos elementos citados, incluindo a responsividade, pode ser consultado [aqui](https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t2-mindtrack/tree/main/codigo-fonte/sidebar). 

# Tela da dashboard
Exibe as principais informações do usuario

![Tela principal do sistema](https://github.com/ICEI-PUC-Minas-PMV-ADS/pmv-ads-2025-1-e1-proj-web-t2-mindtrack/blob/main/documentos/img/imagem_2025-05-02_110508872.png)
