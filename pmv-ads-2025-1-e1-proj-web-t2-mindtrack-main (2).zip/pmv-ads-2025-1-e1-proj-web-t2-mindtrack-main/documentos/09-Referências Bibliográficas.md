# Referências Bibliográficas



> **Links Úteis**:
> (https://www.terra.com.br/noticias/educacao/na-pandemia-67-dos-alunos-tem-dificuldade-de-organizacao,ba3b906910fe78c15ec20517f1882ef1tj66nl60.html
https://www.institutounibanco.org.br/conteudo/apoio-na-organizacao-dos-estudos-e-uma-das-principais-demandas-dos-estudantes/)</br>

>(https://g1.globo.com/ce/ceara/educacao/noticia/2023/11/17/jovens-que-estudam-e-trabalham-falam-sobre-a-rotina-para-conciliar-a-escola-e-o-emprego-a-gente-precisa-fazer-esse-sacrificio.ghtml
)
